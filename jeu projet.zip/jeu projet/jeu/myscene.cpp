#include "MyScene.h"

MyScene::MyScene(QObject* parent) : QGraphicsScene(parent) {

////////Vue

    this->maVue = new QGraphicsView;


////////////////Win








////////////////////////////////Murs

    this->mur1 = new QGraphicsRectItem(0+785, 0+400, 200, 530);
    this->addItem(mur1);
    this->mur1->setBrush(QColorConstants::Black);



    this->mur2 = new QGraphicsRectItem(850+785, 0+400, 50, 700);
    this->addItem(mur2);
    this->mur2->setBrush(QColorConstants::Black);

    this->pmur2 = new QGraphicsRectItem(850+785, 0+400, 10, 700);
    this->addItem(pmur2);
    this->pmur2->setBrush(QColorConstants::Black);

    this->pplafondmur2 = new QGraphicsRectItem(850+785, 690+400, 50, 10);
    this->addItem(pplafondmur2);
    this->pplafondmur2->setBrush(QColorConstants::Black);



    this->mur3 = new QGraphicsRectItem(2147, 640, 200, 580);
    this->addItem(mur3);
    this->mur3->setBrush(QColorConstants::Black);

    this->mur3gauche = new QGraphicsRectItem(2147, 650, 10, 740);
    this->addItem(mur3gauche);
    this->mur3gauche->setBrush(QColorConstants::Black);

    this->mur3droite = new QGraphicsRectItem(2337, 650, 10, 570);
    this->addItem(mur3droite);
    this->mur3droite->setBrush(QColorConstants::Black);



    this->mur4 = new QGraphicsRectItem(2500, 800, 147, 420);
    this->addItem(mur4);
    this->mur4->setBrush(QColorConstants::Black);

    this->mur4gauche = new QGraphicsRectItem(2500, 810, 10, 410);
    this->addItem(mur4gauche);
    this->mur4gauche->setBrush(QColorConstants::Black);

    this->mur4droite = new QGraphicsRectItem(2637, 810, 10, 580);
    this->addItem(mur4droite);
    this->mur4droite->setBrush(QColorConstants::Black);



    this->mur5 = new QGraphicsRectItem(2950, 1150, 100, 250);
    this->addItem(mur5);
    this->mur5->setBrush(QColorConstants::Black);

    this->mur5gauche = new QGraphicsRectItem(2950, 1160, 10, 240);
    this->addItem(mur5gauche);
    this->mur5gauche->setBrush(QColorConstants::Black);



    this->mur6 = new QGraphicsRectItem(3060, 1000, 100, 400);
    this->addItem(mur6);
    this->mur6->setBrush(QColorConstants::Black);

    this->mur6gauche = new QGraphicsRectItem(3060, 1005, 10, 395);
    this->addItem(mur6gauche);
    this->mur6gauche->setBrush(QColorConstants::Black);

    this->mur6droite = new QGraphicsRectItem(3150, 1010, 10, 390);
    this->addItem(mur6droite);
    this->mur6droite->setBrush(QColorConstants::Black);


    this->mur7 = new QGraphicsRectItem(3850, 930, 40, 500);
    this->addItem(mur7);
    this->mur7->setBrush(QColorConstants::Black);

    this->mur7droite = new QGraphicsRectItem(3880, 940, 10, 490);
    this->addItem(mur7droite);
    this->mur7droite->setBrush(QColorConstants::Black);


    this->mur8 = new QGraphicsRectItem(4100, 930, 40, 500);
    this->addItem(mur8);
    this->mur8->setBrush(QColorConstants::Black);

    this->mur8droite = new QGraphicsRectItem(4130, 940, 10, 490);
    this->addItem(mur8droite);
    this->mur8droite->setBrush(QColorConstants::Black);



///////////////////////////Sols

    this->sol0 = new QGraphicsRectItem(785, 1220, 400, 180);
    this->addItem(sol0);
    this->sol0->setBrush(QColorConstants::Black);

    this->sol0mur = new QGraphicsRectItem(1175, 1230, 10, 170);
    this->addItem(sol0mur);
    this->sol0mur->setBrush(QColorConstants::Black);



    this->sol1 = new QGraphicsRectItem(1365, 1220, 670, 180);
    this->addItem(sol1);
    this->sol1->setBrush(QColorConstants::Black);
    //this->sol1->setPen(QColorConstants::White);

    this->sol1mur1 = new QGraphicsRectItem(1365, 1230, 10, 170);
    this->addItem(sol1mur1);
    this->sol1mur1->setBrush(QColorConstants::Black);

    this->sol1mur2 = new QGraphicsRectItem(2025, 1230, 10, 170);
    this->addItem(sol1mur2);
    this->sol1mur2->setBrush(QColorConstants::Black);



    this->sol2 = new QGraphicsRectItem(2147, 1220, 500, 180);
    this->addItem(sol2);
    this->sol2->setBrush(QColorConstants::Black);
    //this->sol1->setPen(QColorConstants::White);

    this->sol2mur1 = new QGraphicsRectItem(2147, 1230, 10, 170);
    this->addItem(sol2mur1);
    this->sol2mur1->setBrush(QColorConstants::Black);

    this->sol2mur2 = new QGraphicsRectItem(2637, 1230, 10, 170);
    //this->addItem(sol2mur2);
    this->sol2mur2->setBrush(QColorConstants::Black);



////////////////////////////////Plateformes


    //plateforme 1
    this->plateforme1 = new QGraphicsRectItem(200+785, 450+400, 250, 80);
    this->addItem(plateforme1);
    this->plateforme1->setBrush(QColorConstants::Black);

//    this->p1m1 = new QGraphicsRectItem(200+785, 455+400, 10, 45);
//    this->addItem(p1m1);
//    this->p1m1->setBrush(QColorConstants::Black);

    this->p1m2 = new QGraphicsRectItem(430+785, 456+400, 20, 76);
    this->addItem(p1m2);
    this->p1m2->setBrush(QColorConstants::Black);

    this->pplafondplat1 = new QGraphicsRectItem(0+785, 490+430, 450, 12);
    this->addItem(pplafondplat1);
    this->pplafondplat1->setBrush(QColorConstants::Black);


    //plateforme 2
    this->plateforme2 = new QGraphicsRectItem(900+785, 460+400, 250, 50);
    this->addItem(plateforme2);
    this->plateforme2->setBrush(QColorConstants::Black);

    this->p2m1 = new QGraphicsRectItem(900+785, 470+400, 10, 40);
    this->addItem(p2m1);
    this->p2m1->setBrush(QColorConstants::Black);

    this->p2m2 = new QGraphicsRectItem(1140+785, 470+400, 10, 40);
    this->addItem(p2m2);
    this->p2m2->setBrush(QColorConstants::Black);

    this->pplafondplat2 = new QGraphicsRectItem(900+785, 500+400, 250, 12);
    this->addItem(pplafondplat2);
    this->pplafondplat2->setBrush(QColorConstants::Black);


    //plateforme 3
    this->plateforme3 = new QGraphicsRectItem(1330, 970, 305, 50);
    this->addItem(plateforme3);
    this->plateforme3->setBrush(QColorConstants::Black);

    this->pplafondplat3 = new QGraphicsRectItem(1330, 990, 305, 30);
    this->addItem(pplafondplat3);
    this->pplafondplat3->setBrush(QColorConstants::Black);

    this->p3m1 = new QGraphicsRectItem(1330, 977, 10, 43);
    this->addItem(p3m1);
    this->p3m1->setBrush(QColorConstants::Black);

//    this->p3m2 = new QGraphicsRectItem(1625, 977, 10, 43);
//    this->addItem(p3m2);
//    this->p3m2->setBrush(QColorConstants::Black);

    //plateforme 4
    this->plateforme4 = new QGraphicsRectItem(2745, 850, 110, 50);
    this->addItem(plateforme4);
    this->plateforme4->setBrush(QColorConstants::Black);

    this->p4m2 = new QGraphicsRectItem(2845, 850, 10, 50);
    this->addItem(p4m2);
    this->p4m2->setBrush(QColorConstants::Black);


    //Plateforme 5
    this->plateforme5 = new QGraphicsRectItem(3300, 1100, 300, 300);
    this->addItem(plateforme5);
    this->plateforme5->setBrush(QColorConstants::Black);

    this->p5m1 = new QGraphicsRectItem(3300, 1110, 10, 290);
    this->addItem(p5m1);
    this->p5m1->setBrush(QColorConstants::Black);

    this->p5m2 = new QGraphicsRectItem(3590, 1110, 10, 290);
    this->addItem(p5m2);
    this->p5m2->setBrush(QColorConstants::Black);

    //Plateforme 6
    this->plateforme6 = new QGraphicsRectItem(3745, 1000, 40, 400);
    this->addItem(plateforme6);
    this->plateforme6->setBrush(QColorConstants::Black);

    this->p6m1 = new QGraphicsRectItem(3745, 1010, 10, 390);
    this->addItem(p6m1);
    this->p6m1->setBrush(QColorConstants::Black);

    this->p6m2 = new QGraphicsRectItem(3775, 1010, 10, 390);
    this->addItem(p6m2);
    this->p6m2->setBrush(QColorConstants::Black);



    //Plateforme 7
    this->plateforme7 = new QGraphicsRectItem(3965, 1000, 40, 400);
    this->addItem(plateforme7);
    this->plateforme7->setBrush(QColorConstants::Black);

    this->p7m1 = new QGraphicsRectItem(3965, 1010, 10, 390);
    this->addItem(p7m1);
    this->p7m1->setBrush(QColorConstants::Black);

    this->p7m2 = new QGraphicsRectItem(3995, 1010, 10, 390);
    this->addItem(p7m2);
    this->p7m2->setBrush(QColorConstants::Black);



    //Plateforme 8
    this->plateforme8 = new QGraphicsRectItem(4240, 1000, 40, 400);
    this->addItem(plateforme8);
    this->plateforme8->setBrush(QColorConstants::Black);

    this->p8m1 = new QGraphicsRectItem(4240, 1010, 10, 390);
    this->addItem(p8m1);
    this->p8m1->setBrush(QColorConstants::Black);

    this->p8m2 = new QGraphicsRectItem(4270, 1010, 10, 390);
    this->addItem(p8m2);
    this->p8m2->setBrush(QColorConstants::Black);

    //Plateforme 9
    this->plateforme9 = new QGraphicsRectItem(4460, 900, 50, 40);
    this->addItem(plateforme9);
    this->plateforme9->setBrush(QColorConstants::Black);

    this->p9m1 = new QGraphicsRectItem(4460, 910, 10, 30);
    this->addItem(p9m1);
    this->p9m1->setBrush(QColorConstants::Black);

    this->p9m2 = new QGraphicsRectItem(4500, 910, 10, 30);
    this->addItem(p9m2);
    this->p9m2->setBrush(QColorConstants::Black);


    //Plateforme 10
    this->plateforme10 = new QGraphicsRectItem(4900, 800, 50, 40);
    this->addItem(plateforme10);
    this->plateforme10->setBrush(QColorConstants::Black);

    this->p10m1 = new QGraphicsRectItem(4900, 810, 10, 30);
    this->addItem(p10m1);
    this->p10m1->setBrush(QColorConstants::Black);

    this->p10m2 = new QGraphicsRectItem(4940, 810, 10, 30);
    this->addItem(p10m2);
    this->p10m2->setBrush(QColorConstants::Black);


    //Plateforme 11
    this->plateforme11 = new QGraphicsRectItem(5400, 900, 200, 500);
    this->addItem(plateforme11);
    this->plateforme11->setBrush(QColorConstants::Black);

    this->p11m1 = new QGraphicsRectItem(5400, 910, 10, 490);
    this->addItem(p11m1);
    this->p11m1->setBrush(QColorConstants::Black);

    this->p11m2 = new QGraphicsRectItem(5590, 910, 10, 490);
    this->addItem(p11m2);
    this->p11m2->setBrush(QColorConstants::Black);


    //Plateforme 12
    this->plateforme12 = new QGraphicsRectItem(5700, 1030, 75, 20);
    this->addItem(plateforme12);
    this->plateforme12->setBrush(QColorConstants::Black);

    this->p12m1 = new QGraphicsRectItem(5700, 1035, 10, 15);
    this->addItem(p12m1);
    this->p12m1->setBrush(QColorConstants::Black);

    this->p12m2 = new QGraphicsRectItem(5765, 1035, 10, 15);
    this->addItem(p12m2);
    this->p12m2->setBrush(QColorConstants::Black);


    //Plateforme 13
    this->plateforme13 = new QGraphicsRectItem(5900, 950, 75, 20);
    this->addItem(plateforme13);
    this->plateforme13->setBrush(QColorConstants::Black);

    this->p13m1 = new QGraphicsRectItem(5900, 955, 10, 15);
    this->addItem(p13m1);
    this->p13m1->setBrush(QColorConstants::Black);

    this->p13m2 = new QGraphicsRectItem(5965, 955, 10, 15);
    this->addItem(p13m2);
    this->p13m2->setBrush(QColorConstants::Black);

    //Plateforme 14
    this->plateforme14 = new QGraphicsRectItem(6100, 1200, 75, 20);
    this->addItem(plateforme14);
    this->plateforme14->setBrush(QColorConstants::Black);

    this->p14m1 = new QGraphicsRectItem(6100, 1200, 5, 20);
    this->addItem(p14m1);
    this->p14m1->setBrush(QColorConstants::Black);

    this->p14m2 = new QGraphicsRectItem(6170, 1200, 5, 20);
    this->addItem(p14m2);
    this->p14m2->setBrush(QColorConstants::Black);

    this->plafondplat14 = new QGraphicsRectItem(6100, 1210, 75, 10);
    this->addItem(plafondplat14);
    this->plafondplat14->setBrush(QColorConstants::Black);



    //Plateforme 15
    this->plateforme15 = new QGraphicsRectItem(6165, 810, 75, 20);
    this->addItem(plateforme15);
    this->plateforme15->setBrush(QColorConstants::Black);

    this->p15m1 = new QGraphicsRectItem(6165, 820, 5, 10);
    this->addItem(p15m1);
    this->p15m1->setBrush(QColorConstants::Black);

    this->p15m2 = new QGraphicsRectItem(6225, 820, 5, 10);
    this->addItem(p15m2);
    this->p15m2->setBrush(QColorConstants::Black);


    //Plateforme 16
    this->plateforme16 = new QGraphicsRectItem(6450, 810, 75, 20);
    this->addItem(plateforme16);
    this->plateforme16->setBrush(QColorConstants::Black);

    this->p16m1 = new QGraphicsRectItem(6450, 820, 5, 10);
    this->addItem(p16m1);
    this->p16m1->setBrush(QColorConstants::Black);

    this->p16m2 = new QGraphicsRectItem(6520, 820, 5, 10);
    this->addItem(p16m2);
    this->p16m2->setBrush(QColorConstants::Black);

    this->plafondplat16 = new QGraphicsRectItem(6450, 825, 75, 5);
    this->addItem(plafondplat16);
    this->plafondplat16->setBrush(QColorConstants::Black);


    //Plateforme 17
    this->plateforme17 = new QGraphicsRectItem(6400, 1100, 75, 20);
    this->addItem(plateforme17);
    this->plateforme17->setBrush(QColorConstants::Black);

    this->p17m1 = new QGraphicsRectItem(6400, 1110, 5, 10);
    this->addItem(p17m1);
    this->p17m1->setBrush(QColorConstants::Black);

    this->p17m2 = new QGraphicsRectItem(6470, 1110, 5, 10);
    this->addItem(p17m2);
    this->p17m2->setBrush(QColorConstants::Black);


    //Plateforme 18
    this->plateforme18 = new QGraphicsRectItem(6675, 1050, 75, 20);
    this->addItem(plateforme18);
    this->plateforme18->setBrush(QColorConstants::Black);

    this->p18m1 = new QGraphicsRectItem(6675, 1060, 5, 10);
    this->addItem(p18m1);
    this->p18m1->setBrush(QColorConstants::Black);

    this->p18m2 = new QGraphicsRectItem(6745, 1060, 5, 10);
    this->addItem(p18m2);
    this->p18m2->setBrush(QColorConstants::Black);

    this->RectTimer3 = new QGraphicsRectItem(6675, 1050, 75, 20);
    this->addItem(RectTimer3);
    this->RectTimer3->setBrush(QColorConstants::Transparent);
    this->RectTimer3->setPen(Qt::NoPen);


    //Plateforme 19
    this->plateforme19 = new QGraphicsRectItem(6900, 925, 75, 20);
    this->addItem(plateforme19);
    this->plateforme19->setBrush(QColorConstants::Black);

    this->p19m1 = new QGraphicsRectItem(6900, 935, 5, 10);
    this->addItem(p19m1);
    this->p19m1->setBrush(QColorConstants::Black);

    this->p19m2 = new QGraphicsRectItem(6970, 935, 5, 10);
    this->addItem(p19m2);
    this->p19m2->setBrush(QColorConstants::Black);


    //Plateforme 20
    this->plateforme20 = new QGraphicsRectItem(7075, 925, 75, 20);
    this->addItem(plateforme20);
    this->plateforme20->setBrush(QColorConstants::Black);


    //Win
    this->RectWin = new QGraphicsRectItem(7201, 810, 40, 40);
    this->addItem(RectWin);
    this->RectWin->setBrush(QColorConstants::Black);





    //Bords de map
    this->limite_bas = new QGraphicsRectItem(0, 1400, 10000, 2600);
    this->addItem(limite_bas);
    this->limite_bas->setBrush(QColorConstants::Black);
    this->limite_bas->setPen(Qt::NoPen);

    this->limite_haut = new QGraphicsRectItem(0, 0, 10000, 400);
    this->addItem(limite_haut);
    this->limite_haut->setBrush(QColorConstants::Black);
    this->limite_haut->setPen(Qt::NoPen);

    this->limite_gauche = new QGraphicsRectItem(0, 400, 785, 3200);
    this->addItem(limite_gauche);
    this->limite_gauche->setBrush(QColorConstants::Black);
    this->limite_gauche->setPen(Qt::NoPen);

    this->limite_droite = new QGraphicsRectItem(7500, 400, 3300, 2500);
    this->addItem(limite_droite);
    this->limite_droite->setBrush(QColorConstants::Black);
    this->limite_droite->setPen(Qt::NoPen);

/////////////////////////////////////////Plafonds

    this->plafond1 = new QGraphicsRectItem(3000, 400, 800, 355);
    this->addItem(plafond1);
    this->plafond1->setBrush(QColorConstants::Black);

    this->plafond1murgauche = new QGraphicsRectItem(3000, 400, 10, 355);
    this->addItem(plafond1murgauche);
    this->plafond1murgauche->setBrush(QColorConstants::Black);

    this->plafond1murdroite = new QGraphicsRectItem(3790, 400, 10, 355);
    this->addItem(plafond1murdroite);
    this->plafond1murdroite->setBrush(QColorConstants::Black);

    this->plafond2 = new QGraphicsRectItem(4000, 400, 600, 200);
    this->addItem(plafond2);
    this->plafond2->setBrush(QColorConstants::Black);

    this->plafond3 = new QGraphicsRectItem(5400, 400, 200, 300);
    this->addItem(plafond3);
    this->plafond3->setBrush(QColorConstants::Black);

    this->plafond3murgauche = new QGraphicsRectItem(5400, 400, 10, 300);
    this->addItem(plafond3murgauche);
    this->plafond3murgauche->setBrush(QColorConstants::Black);

    this->plafond3murdroite = new QGraphicsRectItem(5590, 400, 10, 300);
    this->addItem(plafond3murdroite);
    this->plafond3murdroite->setBrush(QColorConstants::Black);


/////////////////////////////////////////////////////Background image

    this->background.load("background.jpg");



///////////////////////////////////////Scene Taille

    this->setSceneRect(0, 0, background.width()+10000, background.height()+4000);



///////////////////////////////////Personnage


    this->speed = new QGraphicsPixmapItem(QPixmap("ishowspeed.png"));
    this->speed->setScale(0.11); // taille personnage 0.15
    this->speed->setPos(200+785, 100+500); // spawn personnage
    this->addItem(speed);

///////////////////////////////////Piques


    this->pique = QPixmap("pique.png");
    this->petitPique = QPixmap(pique.scaled(62, 62, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    this->retourne = QTransform();                    // Création d'une transformation
    this->retourne2 = QTransform();
    this->retourne3 = QTransform();
    retourne.rotate(180);// Rotation de 180 degrés
    this->piqueAlenvers = QPixmap(petitPique.transformed(retourne));
    //QPixmap piqueAlenvers = petitPique.transformed(retourne);
    //QTransform retourne2;
    retourne2.rotate(-90);
    this->piqueSurlaGauche = QPixmap(petitPique.transformed(retourne2));
    //QPixmap piqueSurlaGauche = petitPique.transformed(retourne2);

    //QTransform retourne3;
    retourne3.rotate(90);
    this->piqueSurlaDroite = QPixmap(petitPique.transformed(retourne3));

    //QPixmap piqueSurlaDroite = petitPique.transformed(retourne3);

    for (int var = 1; var < 3; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(petitPique);
            image->setPos(var*35 + 1116, 799);
            this->addItem(image);
        }

    for (int var = 1; var < 4; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(petitPique);
            image->setPos(var*35 + 1375, 920);
            this->addItem(image);
        }

    for (int var = 1; var < 3; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(petitPique);
            image->setPos(var*35 + 2210, 590);
            this->addItem(image);
        }

    for (int var = 1; var < 5; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(petitPique);
            image->setPos(var*35 + 2305, 1175);
            this->addItem(image);
        }

    for (int var = 1; var < 4; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(petitPique);
            image->setPos(var*35 + 2700, 800);
            this->addItem(image);
        }

    for (int var = 1; var < 2; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(petitPique);
            image->setPos(var*35 + 3070, 950);
            this->addItem(image);
        }

    for (int var = 1; var < 12; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(piqueAlenvers);
            image->setPos(var*40 + 3167, 740);
            this->addItem(image);
        }

    for (int var = 1; var < 4; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(petitPique);
            image->setPos(var*40 + 3348, 1050);
            this->addItem(image);
        }

    for (int var = 1; var < 2; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(petitPique);
            image->setPos(var*35 + 3805, 880);
            this->addItem(image);
        }

    for (int var = 1; var < 2; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(petitPique);
            image->setPos(var*35 + 4055, 880);
            this->addItem(image);
        }

    for (int var = 1; var < 2; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(piqueSurlaGauche);
            image->setPos(var*35 + 5315, 640);
            this->addItem(image);
        }

    for (int var = 1; var < 2; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(piqueSurlaGauche);
            image->setPos(var*35 + 5315, 900);
            this->addItem(image);
        }

    for (int var = 1; var < 2; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(piqueSurlaDroite);
            image->setPos(var*35 + 5555, 640);
            this->addItem(image);
        }

    for (int var = 1; var < 2; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(piqueSurlaDroite);
            image->setPos(var*35 + 5555, 900);
            this->addItem(image);
        }

    this->image = new QGraphicsPixmapItem(petitPique);
    this->image->setPos(6090, 1150);
    this->image->setVisible(false);
    this->addItem(image);



    this->image2 = new QGraphicsPixmapItem(petitPique);
    this->image2->setPos(6125, 1150);
    this->addItem(image2);
    this->image2->setVisible(false);


    this->image3 = new QGraphicsPixmapItem(petitPique);
    this->image3->setPos(6155, 760);
    this->addItem(image3);
    this->image3->setVisible(true);


    this->image4 = new QGraphicsPixmapItem(petitPique);
    this->image4->setPos(6190, 760);
    this->addItem(image4);
    this->image4->setVisible(true);

    for (int var = 1; var < 3; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(petitPique);
            image->setPos(var*35 + 6405, 760);
            this->addItem(image);
        }

    this->image5 = new QGraphicsPixmapItem(petitPique);
    this->image5->setPos(6390, 1060);
    this->addItem(image5);
    this->image5->setVisible(false);

    this->image6 = new QGraphicsPixmapItem(petitPique);
    this->image6->setPos(6425, 1060);
    this->addItem(image6);
    this->image6->setVisible(true);

    this->image7 = new QGraphicsPixmapItem(petitPique);
    this->image7->setPos(7190, 760);
    this->addItem(image7);
    this->image7->setVisible(true);

    this->image8 = new QGraphicsPixmapItem(piqueAlenvers);
    this->image8->setPos(7190, 839);
    this->addItem(image8);
    this->image8->setVisible(true);

    this->image9 = new QGraphicsPixmapItem(piqueSurlaGauche);
    this->image9->setPos(7150, 800);
    this->addItem(image9);
    this->image9->setVisible(true);

    this->image10 = new QGraphicsPixmapItem(piqueSurlaDroite);
    this->image10->setPos(7230, 800);
    this->addItem(image10);
    this->image10->setVisible(true);



    for (int var = 1; var < 26; ++var) {
            QGraphicsPixmapItem* image = new QGraphicsPixmapItem(piqueSurlaGauche);
            image->setPos(7455,var*35 + 400);
            this->addItem(image);
        }



/////////////////////////////////Rectangle invisible pour collision


    this->RectPique1 = new QGraphicsRectItem(1172, 810, 55, 33);
    this->addItem(RectPique1);
    this->RectPique1->setBrush(QColorConstants::Transparent);
    this->RectPique1->setPen(Qt::NoPen);

    this->RectPique2 = new QGraphicsRectItem(1175 +259, 810+121, 80, 33);
    this->addItem(RectPique2);
    this->RectPique2->setBrush(QColorConstants::Transparent);
    this->RectPique2->setPen(Qt::NoPen);

    this->RectPique3 = new QGraphicsRectItem(2258, 600, 50, 33);
    this->addItem(RectPique3);
    this->RectPique3->setBrush(QColorConstants::Transparent);
    this->RectPique3->setPen(Qt::NoPen);

    this->RectPique4 = new QGraphicsRectItem(2365, 1185, 125, 40);
    this->addItem(RectPique4);
    this->RectPique4->setBrush(QColorConstants::Transparent);
    this->RectPique4->setPen(Qt::NoPen);

    this->RectPique5 = new QGraphicsRectItem(2755, 810, 85, 40);
    this->addItem(RectPique5);
    this->RectPique5->setBrush(QColorConstants::Transparent);
    this->RectPique5->setPen(Qt::NoPen);

    this->RectPique6 = new QGraphicsRectItem(3130, 955, 27, 45);
    this->addItem(RectPique6);
    this->RectPique6->setBrush(QColorConstants::Transparent);
    this->RectPique6->setPen(Qt::NoPen);

    this->RectPique7 = new QGraphicsRectItem(3225, 755, 420, 40);
    this->addItem(RectPique7);
    this->RectPique7->setBrush(QColorConstants::Transparent);
    this->RectPique7->setPen(Qt::NoPen);

    this->RectPique8 = new QGraphicsRectItem(3412, 1060, 100, 40);
    this->addItem(RectPique8);
    this->RectPique8->setBrush(QColorConstants::Transparent);
    this->RectPique8->setPen(Qt::NoPen);

    this->RectPique9 = new QGraphicsRectItem(3853, 885, 35, 45);
    this->addItem(RectPique9);
    this->RectPique9->setBrush(QColorConstants::Transparent);
    this->RectPique9->setPen(Qt::NoPen);

    this->RectPique10 = new QGraphicsRectItem(4103, 885, 35, 45);
    this->addItem(RectPique10);
    this->RectPique10->setBrush(QColorConstants::Transparent);
    this->RectPique10->setPen(Qt::NoPen);

    this->RectPique11 = new QGraphicsRectItem(5363, 660, 37, 25);
    this->addItem(RectPique11);
    this->RectPique11->setBrush(QColorConstants::Transparent);
    this->RectPique11->setPen(Qt::NoPen);

    this->RectPique12 = new QGraphicsRectItem(5360, 920, 40, 25);
    this->addItem(RectPique12);
    this->RectPique12->setBrush(QColorConstants::Transparent);
    this->RectPique12->setPen(Qt::NoPen);

    this->RectPique13 = new QGraphicsRectItem(5601, 660, 35, 25);
    this->addItem(RectPique13);
    this->RectPique13->setBrush(QColorConstants::Transparent);
    this->RectPique13->setPen(Qt::NoPen);

    this->RectPique14 = new QGraphicsRectItem(5601, 920, 40, 25);
    this->addItem(RectPique14);
    this->RectPique14->setBrush(QColorConstants::Transparent);
    this->RectPique14->setPen(Qt::NoPen);

    this->RectPique15 = new QGraphicsRectItem(6103, 1170, 68, 25);
    this->addItem(RectPique15);
    this->RectPique15->setBrush(QColorConstants::Transparent);
    this->RectPique15->setPen(Qt::NoPen);

    this->RectTimer = new QGraphicsRectItem(6108, 1170, 60, 25);
    this->addItem(RectTimer);
    this->RectTimer->setBrush(QColorConstants::Transparent);
    this->RectTimer->setPen(Qt::NoPen);

    this->FakePique = new QGraphicsRectItem(6150, 600, 95, 210);
    this->addItem(FakePique);
    this->FakePique->setBrush(QColorConstants::Transparent);
    this->FakePique->setPen(Qt::NoPen);

    this->RectPique16 = new QGraphicsRectItem(6454, 777, 70, 31);
    this->addItem(RectPique16);
    this->RectPique16->setBrush(QColorConstants::Transparent);
    this->RectPique16->setPen(Qt::NoPen);

    this->RectPique17 = new QGraphicsRectItem(6402, 1070, 35, 31);
    this->addItem(RectPique17);
    this->RectPique17->setBrush(QColorConstants::Transparent);
    this->RectPique17->setPen(Qt::NoPen);

    this->RectTimer2 = new QGraphicsRectItem(6402, 1070, 30, 31);
    this->addItem(RectTimer2);
    this->RectTimer2->setBrush(QColorConstants::Transparent);
    this->RectTimer2->setPen(Qt::NoPen);

    this->RectPique18 = new QGraphicsRectItem(6442, 1070, 30, 31);
    this->addItem(RectPique18);
    this->RectPique18->setBrush(QColorConstants::Transparent);
    this->RectPique18->setPen(Qt::NoPen);

    this->RectPique19 = new QGraphicsRectItem(7465, 400, 30, 900);
    this->addItem(RectPique19);
    this->RectPique19->setBrush(QColorConstants::Transparent);
    this->RectPique19->setPen(Qt::NoPen);

//////////////////////////////Décor

    this->baril = new QGraphicsPixmapItem(QPixmap("baril.png"));
    this->baril->setScale(1.1);
    this->baril->setPos(750, 996);
    this->addItem(baril);


//    this->statue = new QGraphicsPixmapItem(QPixmap("statue-chad.png"));
//    this->statue->setScale(0.3);
//    this->statue->setPos(1470, 785);
//    this->addItem(statue);

    QPixmap statue("statue-chad.png");
    QPixmap petiteStatue = statue.scaled(250, 850, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    QTransform transformation;                    // Création d'une transformation
    transformation.rotate(180, Qt::YAxis);                    // Rotation de 180 degrés
    QPixmap statueRotate = petiteStatue.transformed(transformation);

    this->statueChad = new QGraphicsPixmapItem(statueRotate);
    this->statueChad->setPos(1460, 765);
    this->addItem(statueChad);


    QPixmap fleche("fleche.png");
    QPixmap petiteFleche = fleche.scaled(100, 75, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    QTransform transformation2;                    // Création d'une transformation
    transformation2.rotate(180, Qt::YAxis);                    // Rotation de 180 degrés
    QPixmap FlecheRotate = petiteFleche.transformed(transformation2);

    this->Fleche = new QGraphicsPixmapItem(FlecheRotate);
    //this->Fleche->setScale(0.15);
    this->Fleche->setPos(7210, 700);
    this->addItem(Fleche);



    this->Press_R = new QGraphicsTextItem("Appuyez sur R ");
    this->Press_R->setFont(QFont("Calibri", 15, QFont::Bold));
    this->Press_R->setDefaultTextColor(Qt::black);
    this->Press_R->setPos(7300, 700);
    this->addItem(Press_R);



//    this->spacebar = new QGraphicsPixmapItem(QPixmap("spacebar.png"));
//    this->spacebar->setScale(0.07);
//    this->spacebar->setPos(600, 750);
//    this->addItem(spacebar);

//    this->keyQ = new QGraphicsPixmapItem(QPixmap("keyQ.png"));
//    this->keyQ->setScale(0.5);
//    this->keyQ->setPos(610, 650);
//    this->addItem(keyQ);

//    this->keyD = new QGraphicsPixmapItem(QPixmap("keyD.png"));
//    this->keyD->setScale(0.5);
//    this->keyD->setPos(695, 650);
//    this->addItem(keyD);


//////////////////////////Plafond

    QPixmap image_plafond("plafond.png");
    //this->image_plafond->setScale(0.12);
    //this->image_plafond->setPos(720, -130);
    //this->addItem(image_plafond);

    int nbImages = 11;
    int imageWidth = 653;
    int imageHeight = 100;

    for (int var = 1; var < nbImages; ++var) {
        QGraphicsPixmapItem* pixmap = new QGraphicsPixmapItem(image_plafond);
        pixmap->setPos(var * imageWidth+70, -130);
        this->addItem(pixmap);
    }


/////////////////////Murs map

//    QPixmap image_bord_map("murs.jpg");
//    QTransform transformation;                    // Création d'une transformation
//    transformation.rotate(90);                    // Rotation de 90 degrés
//    QPixmap mursRotate = image_bord_map.transformed(transformation);

//    for (int var = 1; var < 10; ++var) {
//        QGraphicsPixmapItem* image = new QGraphicsPixmapItem(mursRotate);
//        image->setPos(683, var* 130 +270);
//        this->addItem(image);
//    }


///////////////////Chronometre

    this->chronometre = new QGraphicsSimpleTextItem();
    this->chronometre->setScale(2);
    this->chronometre->setBrush(QColorConstants::White);
    //this->chronometre->setPos(1350 , 0);
    this->addItem(chronometre);



/////////////////////////Timer

    timer = new QTimer(this);
    //connect(timer, SIGNAL(timeout()), this, SLOT(update()));
    connect(timer, &QTimer::timeout, this, [=]() {
        this->update();
        // Incrémenter le temps écoulé
        static int tempsEcoule = 0;
        tempsEcoule++;

        if (!sceneRect().contains(this->speed->pos()) || ResetChrono == true) {
            tempsEcoule = 0;
            }

        // Mettre à jour le texte du chronomètre
        this->minutes = tempsEcoule / 6000;
        this->secondes = tempsEcoule % 6000;
        QString texteChronometre = QString("Temps: %1:%2")
            .arg(minutes, 2, 10, QLatin1Char('0'))
            .arg(secondes/100, 2, 10, QLatin1Char('0'));
        this->chronometre->setText(texteChronometre);


    });
    this->timer->start(10); //vitesse personnage

//    this->pos = QPointF();
//    this->posplat2 = QPointF(); //récupération de la position de la plateforme 2
//    this->pospetplat1 = QPointF(); //récupération de la position de la petite plateforme n°1 de la plateforme 2
//    this->pospetplat2 = QPointF(); //récupération de la position de la petite plateforme n°2 de la plateforme 2
//    this->posplafondplat2 = QPointF();

//    this->posplat9 = QPointF(); //récupération de la position de la plateforme 9
//    this->posp9m1 = QPointF(); //récupération de la position de la petite plateforme n°1 de la plateforme 9
//    this->posp9m2 = QPointF(); //récupération de la position de la petite plateforme n°2 de la plateforme 9

//    this->posplat10 = QPointF();
//    this->posp10m1 = QPointF();
//    this->posp10m2 = QPointF();

////////////Initialisations

    this->pauseGame = false;
    this->RemoveWinScreen = false;
    this->vx = 0;
    this->vy = 0;
    this->gravite = 4;
    this->vitessePlat2 = 2;
    this->vitessePlat9 = 3;
    this->vitessePlat10 = 4;
    this->vitessePlat18 = 0;
    this->saut = 0;
    this->jump = false;
    this->onGround = false;
    this->onMap = false;
    this->appear = false;
    this->speedRespawnPlat18 = false;
    this->speedRespawnPlat17 = false;
    this->restart = false;
    this->ResetChrono = false;
    this->VitRectTimer=0;
    this->VitRectTimer2=0;

//    if(this->ResetChrono == false){
//        this->tempsEcoule = 0;
//    }
}


///////////////////////////////Background Taille

void MyScene::drawBackground(QPainter *painter, const QRectF &rect) {
    Q_UNUSED(rect);

    for (int var = 1; var <= 4; ++var) {
        painter->drawPixmap(QRectF(2320*var - 1550 , 348 ,background.width()+30000, background.height()+10000), background, sceneRect());
    }
}

////////////////////////////Destructeur

MyScene::~MyScene() {
    delete this->timer;
}


///////////////////////////////////Collisions

void MyScene::collision(){
    QPointF pos = this->speed->pos();
    //plateforme (dessus)

    if (speed->collidesWithItem(plateforme1) || speed->collidesWithItem(limite_bas) || speed->collidesWithItem(plateforme3) || speed->collidesWithItem(sol0) || speed->collidesWithItem(sol1)
          || speed->collidesWithItem(mur5) || speed->collidesWithItem(plateforme9) || speed->collidesWithItem(plateforme10) || speed->collidesWithItem(plateforme11)
          || speed->collidesWithItem(plateforme14) || speed->collidesWithItem(plateforme17) || speed->collidesWithItem(plateforme18)){
        gravite = 0;
    }
    else{
        gravite = 4;
    }

    //plateforme qui bouge (dessus)
    if (speed->collidesWithItem(plateforme2)){
        gravite = -2;
    }

    //plateforme qui bouge (plafond)
    if (speed->collidesWithItem(pplafondplat2) ){
        gravite = 8;
    }

    if (speed->collidesWithItem(p2m2)){
        gravite = 4;
        this->speed->setPos(pos.x()+4, pos.y()+4);
    }


    if (speed->collidesWithItem(plateforme9)){
        if(vitessePlat9 == -3)
            onPlat9 = -3;
        if(vitessePlat9 == 3)
            onPlat9 = 3;
    }
    else
        onPlat9 = 0;

    if (speed->collidesWithItem(plateforme10)){
        if(vitessePlat10 == -4)
            onPlat10 = -4;
        if(vitessePlat10 == 4)
            onPlat10 = 4;
    }
    else
        onPlat10 = 0;




    if (speed->collidesWithItem(RectPique15)){
        this->VitRectTimer = 5;
        this->image->setVisible(true);
        this->image2->setVisible(true);
        this->RectTimer->setPos(this->RectTimer->pos().rx(), this->RectTimer->pos().ry()+VitRectTimer);
        if(this->RectTimer->pos().ry() > 90){//timer: (on augmente la valeur du nombre pour augmenter le temps pour laquel je me fais tuer par les piques qui pop)
            respawn();
        }

    }
    else {
        this->image->setVisible(false);
        this->image2->setVisible(false);
        this->RectTimer->setPos(0, 0);
    }

    if(speed->collidesWithItem(FakePique)){
        this->image3->setVisible(false);
        this->image4->setVisible(false);
    }
    else{
        this->image3->setVisible(true);
        this->image4->setVisible(true);
    }








    if(speed->collidesWithItem(plateforme17)){
        this->speedRespawnPlat17 = false;
        if(speed->collidesWithItem(RectPique17)){
            this->VitRectTimer2 = 5;
            this->image5->setVisible(true);
            this->image6->setVisible(false);
            this->RectTimer2->setPos(this->RectTimer2->pos().rx(), this->RectTimer2->pos().ry()+VitRectTimer2);
            if(this->RectTimer2->pos().ry() > 30){
                respawn();
            }
        }
        else{
            this->image5->setVisible(false);
            this->image6->setVisible(true);
            this->RectTimer2->setPos(0, 0);
        }
    }

    if(this->speedRespawnPlat17 == true){
        this->image5->setVisible(false);
        this->image6->setVisible(true);
    }


    if(speed->collidesWithItem(RectPique18)){
        this->image5->setVisible(true);
        this->image6->setVisible(false);
    }


    if(speed->collidesWithItem(plateforme18)){
        this->speedRespawnPlat18 = false;
        VitRectTimer3 = 5;
        this->RectTimer3->setPos(this->RectTimer3->pos().rx(), this->RectTimer3->pos().ry()+VitRectTimer3);

        if(this->RectTimer3->pos().ry() > 45){
            vitessePlat18+=0.9;
        }
    }


    if(speedRespawnPlat18 == true){
        this->plateforme18->setPos(0, 0);
        this->p18m1->setPos(0, 0);
        this->p18m2->setPos(0, 0);
        this->RectTimer3->setPos(0, 0);
    }




    //murs à prendre de la gauche
    if(speed->collidesWithItem(p2m1) || speed->collidesWithItem(pmur2) || speed->collidesWithItem(limite_droite) || speed->collidesWithItem(mur4gauche)
           || speed->collidesWithItem(plafond1murgauche) || speed->collidesWithItem(mur6gauche) || speed->collidesWithItem(plateforme4)
            || speed->collidesWithItem(p5m1) || speed->collidesWithItem(p6m1) || speed->collidesWithItem(mur7) || speed->collidesWithItem(p7m1)
            || speed->collidesWithItem(mur8) || speed->collidesWithItem(p8m1) || speed->collidesWithItem(plafond3murgauche)  ){
        this->speed->setPos(pos.x()-4, pos.y());
    }

    //dessus de murs/plateformes
    if(speed->collidesWithItem(mur3) || speed->collidesWithItem(mur4) || speed->collidesWithItem(sol2) || speed->collidesWithItem(mur6)
            || speed->collidesWithItem(plateforme5) || speed->collidesWithItem(plateforme6) || speed->collidesWithItem(plateforme7)
            || speed->collidesWithItem(plateforme8) || speed->collidesWithItem(plateforme12) || speed->collidesWithItem(plateforme13)
            || speed->collidesWithItem(plateforme14)|| speed->collidesWithItem(plateforme15) || speed->collidesWithItem(plateforme16)
            || speed->collidesWithItem(plateforme19)){
        this->speed->setPos(pos.x(), pos.y()-4);
    }



    //murs à prendre de la droite (en l'air)
    if(speed->collidesWithItem(p1m2) || speed->collidesWithItem(p3m2) || speed->collidesWithItem(sol1mur2)
            || speed->collidesWithItem(sol0mur) || speed->collidesWithItem(p9m2) || speed->collidesWithItem(p10m2)
            || speed->collidesWithItem(p11m2) /*|| speed->collidesWithItem(p14m2)*/ || speed->collidesWithItem(p17m2)
            || speed->collidesWithItem(p18m2)){
        this->speed->setPos(pos.x()+4, pos.y()+4); // collision pour que la gravité joue aussi
    }

    //murs à prendre de la gauche (en l'air)
    if(speed->collidesWithItem(p3m1)  || speed->collidesWithItem(sol2mur1) || speed->collidesWithItem(statueChad) || speed->collidesWithItem(sol1mur1) || speed->collidesWithItem(mur3gauche)
            || speed->collidesWithItem(mur5gauche) || speed->collidesWithItem(p9m1) || speed->collidesWithItem(p10m1) || speed->collidesWithItem(p11m1)
            /*|| speed->collidesWithItem(p14m1) */|| speed->collidesWithItem(p17m1) || speed->collidesWithItem(p18m1)){
        this->speed->setPos(pos.x()-4, pos.y()+4); // collision pour que la gravité joue aussi
    }

    if(speed->collidesWithItem(p14m1)){
        this->speed->setPos(pos.x()-4.1, pos.y()+4);
    }

    if(speed->collidesWithItem(p14m2)){
        this->speed->setPos(pos.x()+4.5, pos.y()+4);
    }

        //murs à prendre de la gauche
        if(speed->collidesWithItem(p12m1) || speed->collidesWithItem(p13m1)  || speed->collidesWithItem(p15m1) || speed->collidesWithItem(p16m1)
            || speed->collidesWithItem(p19m1)){
          this->speed->setPos(pos.x()-4, pos.y());
        }

        //murs à prendre de la droite (bis)
        if(speed->collidesWithItem(p12m2) || speed->collidesWithItem(p13m2) || speed->collidesWithItem(p15m2) || speed->collidesWithItem(p16m2)
                || speed->collidesWithItem(p19m2)){
          this->speed->setPos(pos.x()+4, pos.y());
        }


    //murs à prendre de la droite
    if(speed->collidesWithItem(mur1) || speed->collidesWithItem(mur2) || speed->collidesWithItem(limite_gauche)  || speed->collidesWithItem(baril)
            || speed->collidesWithItem(mur3droite) || speed->collidesWithItem(mur4droite) || speed->collidesWithItem(sol2mur2) || speed->collidesWithItem(plafond1murdroite)
            || speed->collidesWithItem(mur6droite) || speed->collidesWithItem(p5m2) || speed->collidesWithItem(p6m2) || speed->collidesWithItem(mur7droite)
            || speed->collidesWithItem(p4m2) || speed->collidesWithItem(p7m2) || speed->collidesWithItem(mur8droite) || speed->collidesWithItem(p8m2)
            || speed->collidesWithItem(plafond3murdroite) || speed->collidesWithItem(p11m2) ){
        this->speed->setPos(pos.x()+4, pos.y() );
    }

    //plafonds/bas de plateformes
    if(speed->collidesWithItem(pplafondplat1) || speed->collidesWithItem(pplafondplat2)|| speed->collidesWithItem(limite_haut) || speed->collidesWithItem(plafond1)
        || speed->collidesWithItem(plafondplat14) || speed->collidesWithItem(plafondplat16)){
        this->speed->setPos(pos.x(), pos.y()+4);
    }

    //plafond bas (pour pas le transperser avec le saut)
    if(speed->collidesWithItem(plafond3) || speed->collidesWithItem(pplafondmur2)){
        this->speed->setPos(pos.x(), pos.y()+4);
        saut = 0;
    }

    if(speed->collidesWithItem(pplafondplat3)){
        this->speed->setPos(pos.x(), pos.y()+6);
        saut = 0;
    }


    //plateformes ou on peut sauter ou aller dessus
    if(speed->collidesWithItem(plateforme1) || speed->collidesWithItem(plateforme2) || speed->collidesWithItem(plateforme3) || speed->collidesWithItem(sol0) || speed->collidesWithItem(sol1)
            || speed->collidesWithItem(sol2) || speed->collidesWithItem(mur3) || speed->collidesWithItem(mur4) || speed->collidesWithItem(mur5) || speed->collidesWithItem(mur6)
            || speed->collidesWithItem(plateforme5) || speed->collidesWithItem(plateforme6) || speed->collidesWithItem(plateforme7) || speed->collidesWithItem(plateforme8)
            || speed->collidesWithItem(plateforme9) || speed->collidesWithItem(plateforme10) || speed->collidesWithItem(plateforme11) || speed->collidesWithItem(plateforme12)
            || speed->collidesWithItem(plateforme13) || speed->collidesWithItem(plateforme14) || speed->collidesWithItem(plateforme15) || speed->collidesWithItem(plateforme16)
            || speed->collidesWithItem(plateforme17) || speed->collidesWithItem(plateforme18) || speed->collidesWithItem(plateforme19))
        this->onGround = true;
    else
        this->onGround = false;

/////////////////////////////// respawn du personnage

        if (!sceneRect().contains(this->speed->pos()) || speed->collidesWithItem(limite_bas) || speed->collidesWithItem(RectPique1)
                || speed->collidesWithItem(RectPique2) || speed->collidesWithItem(RectPique3) || speed->collidesWithItem(RectPique4)
                || speed->collidesWithItem(RectPique5) || speed->collidesWithItem(RectPique6) || speed->collidesWithItem(RectPique7)
                || speed->collidesWithItem(RectPique8) || speed->collidesWithItem(RectPique9) || speed->collidesWithItem(RectPique10)
                || speed->collidesWithItem(RectPique11) || speed->collidesWithItem(RectPique12) || speed->collidesWithItem(RectPique13)
                || speed->collidesWithItem(RectPique14) || speed->collidesWithItem(RectPique16) || speed->collidesWithItem(RectPique19)){
            respawn();
            }





}


/////////////////////////////////////////Items en action

void MyScene::update(){
    this->maVue = this->views()[1];
    maVue->centerOn(speed);


    QPointF pos = this->speed->pos();
    //this->pos = this->speed->pos(); //récupération de la position du personnage
    QPointF posplat2 = this->plateforme2->pos(); //récupération de la position de la plateforme 2
    QPointF pospetplat1 = this->p2m1->pos(); //récupération de la position de la petite plateforme n°1 de la plateforme 2
    QPointF pospetplat2 = this->p2m2->pos(); //récupération de la position de la petite plateforme n°2 de la plateforme 2
    QPointF posplafondplat2 = this->pplafondplat2->pos();

    QPointF posplat9 = this->plateforme9->pos(); //récupération de la position de la plateforme 9
    QPointF posp9m1 = this->p9m1->pos(); //récupération de la position de la petite plateforme n°1 de la plateforme 9
    QPointF posp9m2 = this->p9m2->pos(); //récupération de la position de la petite plateforme n°2 de la plateforme 9

    QPointF posplat10 = this->plateforme10->pos();
    QPointF posp10m1 = this->p10m1->pos();
    QPointF posp10m2 = this->p10m2->pos();

//    if(pos.ry() < 700)
//        this->speed->setPos(pos.rx()+vx, pos.ry()+vy);
    this->speed->setPos(pos.rx()+vx+onPlat9+onPlat10, pos.ry()+vy+gravite+saut); //incrémentation de la coordonnée y pour avoir une gravité

    this->plateforme2->setPos(posplat2.rx(), posplat2.ry()+vitessePlat2); // incrémentation d'une vitesse sur la plateforme qui bouge
    this->p2m1->setPos(pospetplat1.rx(), pospetplat1.ry()+vitessePlat2); // idem sur les petites
    this->p2m2->setPos(pospetplat2.rx(), pospetplat2.ry()+vitessePlat2); // idem
    this->pplafondplat2->setPos(posplafondplat2.rx(), posplafondplat2.ry()+vitessePlat2);

    this->plateforme9->setPos(posplat9.rx()+vitessePlat9, posplat9.ry());
    this->p9m1->setPos(posp9m1.rx()+vitessePlat9, posp9m1.ry());
    this->p9m2->setPos(posp9m2.rx()+vitessePlat9, posp9m2.ry());

    this->plateforme10->setPos(posplat10.rx()+vitessePlat10, posplat10.ry());
    this->p10m1->setPos(posp10m1.rx()+vitessePlat10, posp10m1.ry());
    this->p10m2->setPos(posp10m2.rx()+vitessePlat10, posp10m2.ry());

    this->plateforme18->setPos(this->plateforme18->pos().x(), this->plateforme18->pos().y()+vitessePlat18);
    this->p18m1->setPos(this->p18m1->pos().x(), this->p18m1->pos().y()+vitessePlat18);
    this->p18m2->setPos(this->p18m2->pos().x(), this->p18m2->pos().y()+vitessePlat18);

    this->chronometre->setPos(this->speed->pos().x() + 650 , this->speed->pos().y() - 360 );


/////////////fonctionnement des collisions

    collision();


///////////////////////boucles pour que la plateforme (on inclue les petites) monte et descende

    if (posplat2.ry() > 200 || pospetplat1.ry() > 200 || pospetplat2.ry() > 200 || posplafondplat2.ry() > 200) {
        vitessePlat2 = -2;
                  //rajout d'une plateforme (a l'interieur de la grande) pour ne pas pouvoir passer a l'interieur de la grande par les cotés
    }

    if (posplat2.ry() < -215 || pospetplat1.ry() < -215 || pospetplat2.ry() < -215 || posplafondplat2.ry() < -215) {
        vitessePlat2 = 2;
                             //rajout d'une plateforme (a l'interieur de la grande) pour ne pas pouvoir passer a l'interieur de la grande par les cotés
        }

    if (posplat9.rx() > 300 || posp9m1.rx() > 300 || posp9m2.rx() > 300 ) {
        vitessePlat9 = -3;
        }


    if (posplat9.rx() < -15 || posp9m1.rx() < -15 || posp9m2.rx() < -15 ) {
        vitessePlat9 = 3;
    }

    if (posplat10.rx() > 250 || posp10m1.rx() > 250 || posp10m2.rx() > 250 ) {
        vitessePlat10 = -4;
        }


    if (posplat10.rx() < -20 || posp10m1.rx() < -20 || posp10m2.rx() < -20 ) {
        vitessePlat10 = 4;
    }


/////////////////////////Saut


    if(this->jump == true ){
        if(this->saut < 4)
            saut+=0.5;
    }
    if(this->onGround == true){
        saut = 0;
        this->jump = false;
    }


//    for (int var = 1; var < 3; ++var) {
            //this->image = new QGraphicsPixmapItem(petitPique);


//        }



}
//////////////////fin de la fonction update (Items en action)




/////////////////Actions lorsque on appuie sur des touches du clavier

void MyScene::keyPressEvent(QKeyEvent* event){
    if(event->key() == Qt::Key_D) {
        vx += 4;
     }
    if(event->key() == Qt::Key_Q) {
        vx -= 4;
     }
//    if(event->key() == Qt::Key_Z) {
//        vy-=8;
//     }

//    if(event->key() == Qt::Key_R) {
//        this->restart = true;
//     }

//    if(event->key() == Qt::Key_Shift) {
//        this->speed->setScale(0.05);
//     }




////////////////////Saut

    if(this->onGround == true){
        if(event->key() == Qt::Key_Space) {
            this->saut = 0;
            this->saut -=17;
            this->jump = true;
         }

    }


//    if(event->key() == Qt::Key_S) {
//        vy+=4;
//     }

//    if(event->key() == Qt::Key_S && event->key() == Qt::Key_Q){
//           vx-=4;
//           vy+=4;
//       }
//       if(event->key() == Qt::Key_S && event->key() == Qt::Key_D){
//           vx+=4;
//           vy+=4;
//       }
//       if(event->key() == Qt::Key_Z && event->key() == Qt::Key_D){
//           vx+=4;
//           vy-=4;
//       }
//       if(event->key() == Qt::Key_Z && event->key() == Qt::Key_Q){
//           vx-=4;
//           vy-=4;
//       }


//    if(!pauseGame && event->key() == Qt::Key_Z) { // appui sur la touche Z du clavier
//        vitesseAvion+=10;
//     }



////////////////Affichage d'un bouton pause
if(!speed->collidesWithItem(RectWin) /*|| !this->Dead == true*/){
    if(event->key() == Qt::Key_P){
        if(!pauseGame){
            pauseGame = true;
            timer->stop();
            this->pauseScreen = new QGraphicsRectItem(sceneRect());
            this->pauseScreen->setBrush(QBrush(QColor(0, 0, 0, 128))); // Couleur semi-transparente
            this->pauseScreen->setZValue(1); // Mettre en avant-plan
            this->pauseScreen->setVisible(true); // Masquer l'écran de pause par défaut avec un false
            this->addItem(pauseScreen);

            this->pauseText = new QGraphicsTextItem("PAUSE");
            this->pauseText->setFont(QFont("Arial", 24, QFont::Bold));
            this->pauseText->setDefaultTextColor(Qt::white);
            this->pauseText->setPos(/*sceneRect().center() - pauseText->boundingRect().center()*/ this->speed->pos().x(),  this->speed->pos().y()+20);
            this->pauseText->setZValue(2); // Mettre en avant-plan par-dessus l'écran de pause
            this->pauseText->setVisible(true); // Masquer le texte de pause par défaut avec un false
            this->addItem(pauseText);

        }
        else{
            pauseGame = false;
            timer->start(10);
            this->removeItem(pauseScreen);
            this->removeItem(pauseText);
            delete pauseScreen;
            delete pauseText;
        }

    }
}







    /////////////////////////Affichage Win




            if(speed->collidesWithItem(RectWin)){
                if(event->key() == Qt::Key_R){
                    if(!RemoveWinScreen){
                        RemoveWinScreen = true;
                        timer->stop();
                        this->WinScreen = new QGraphicsRectItem(sceneRect());
                        this->WinScreen->setBrush(QBrush(QColor(0, 0, 0, 128))); // Couleur semi-transparente
                        this->WinScreen->setZValue(1); // Mettre en avant-plan
                        this->WinScreen->setVisible(true); // Masquer l'écran de win par défaut avec un false
                        this->addItem(WinScreen);


                        this->WinText = new QGraphicsTextItem("GG !!");
                        this->WinText->setFont(QFont("Arial", 100, QFont::Bold));
                        this->WinText->setDefaultTextColor(Qt::white);
                        this->WinText->setPos(this->speed->pos().x()-150,  this->speed->pos().y());
                        this->WinText->setZValue(2); // Mettre en avant-plan par-dessus l'écran de win
                        this->WinText->setVisible(true); // Masquer le texte de win par défaut avec un false
                        this->addItem(WinText);


                        this->WinText2 = new QGraphicsTextItem("Appuyez sur R pour recommencer");
                        this->WinText2->setFont(QFont("Arial", 15, QFont::Bold));
                        this->WinText2->setDefaultTextColor(Qt::white);
                        this->WinText2->setPos(this->speed->pos().x()-150,  this->speed->pos().y()+180);
                        this->WinText2->setZValue(2); // Mettre en avant-plan par-dessus l'écran de win
                        this->WinText2->setVisible(true); // Masquer le texte de win par défaut avec un false
                        this->addItem(WinText2);

//                        this->WinText3 = new QGraphicsTextItem("Votre temps est de :");
//                        this->WinText3->setFont(QFont("Arial", 15, QFont::Bold));
//                        this->WinText3->setDefaultTextColor(Qt::white);
//                        this->WinText3->setPos(this->chronometre->pos().x()-200,  this->chronometre->pos().y());
//                        this->WinText3->setZValue(2); // Mettre en avant-plan par-dessus l'écran de win
//                        this->WinText3->setVisible(true); // Masquer le texte de win par défaut avec un false
//                        this->addItem(WinText3);

                        this->speed_content = new QGraphicsPixmapItem(QPixmap("speed_content.png"));
                        this->speed_content->setScale(0.9);
                        this->speed_content->setPos(this->speed->pos().x()-750,  this->speed->pos().y()+150);
                        this->speed_content->setZValue(2); // Mettre en avant-plan par-dessus l'écran de win
                        this->speed_content->setVisible(true); // Masquer le texte de win par défaut avec un false
                        this->addItem(speed_content);

                        this->speed_mental = new QGraphicsPixmapItem(QPixmap("speed_mental.png"));
                        this->speed_mental->setScale(0.4);
                        this->speed_mental->setPos(this->speed->pos().x()+325,  this->speed->pos().y());
                        this->speed_mental->setZValue(2); // Mettre en avant-plan par-dessus l'écran de win
                        this->speed_mental->setVisible(true); // Masquer le texte de win par défaut avec un false
                        this->addItem(speed_mental);

                        this->confettis = new QGraphicsPixmapItem(QPixmap("confettis.png"));
                        this->confettis->setScale(1.5);
                        this->confettis->setPos(this->speed->pos().x()-710,  this->speed->pos().y()-400);
                        this->confettis->setZValue(2); // Mettre en avant-plan par-dessus l'écran de win
                        this->confettis->setVisible(true); // Masquer le texte de win par défaut avec un false
                        this->addItem(confettis);

                        this->Score = new QGraphicsRectItem(this->speed->pos().x()+645, this->speed->pos().y()-365, 150, 50);
                        this->Score->setBrush(QColorConstants::Transparent);
                        this->Score->setPen(QColorConstants::Red);
                        this->Score->setZValue(2);
                        this->Score->setVisible(true);
                        this->addItem(Score);

                    }


                    else{
                        RemoveWinScreen = false;
                        this->ResetChrono = true;
                        respawn();
                        timer->start(10);
                        this->secondes = 0;
                        this->minutes = 0;
                        this->removeItem(WinScreen);
                        this->removeItem(WinText);
                        this->removeItem(WinText2);
                        //this->removeItem(WinText3);
                        this->removeItem(speed_content);
                        this->removeItem(confettis);
                        this->removeItem(Score);

                        delete WinScreen;
                        delete WinText;
                        delete WinText2;
                        //delete WinText3;
                        delete speed_content;
                        delete speed_mental;
                        delete confettis;
                        delete Score;
                    }

                }

            }



    qDebug() << "touche clavier : " << event->key();
}

void MyScene::keyReleaseEvent(QKeyEvent *event){
//    if(event->key() == Qt::Key_S) {
//        this->vy = 0;
//    }
//    if(event->key() == Qt::Key_Z) {
//        this->vy = 0;
//    }
    if(event->key() == Qt::Key_Q) {
        this->vx = 0;

    }
    if(event->key() == Qt::Key_D) {
        this->vx = 0;
    }

    if(event->key() == Qt::Key_R) {
        this->ResetChrono = false;
     }




/////////////////////////Saut
    if(this->onGround == true){
        if(event->key() == Qt::Key_Space) {
            this->saut = 0;
            this->jump = false;
        }
    }
}


void MyScene::respawn(){
    this->speed->setPos(985, 500  /*7200, 600*/); // coordonnées du respawn
    this->gravite = 4;
    this->saut=0;
    this->jump = false;
    this->speedRespawnPlat18 = true;
    this->speedRespawnPlat17 = true;
    this->vitessePlat18 = 0;
    this->VitRectTimer3 = 0;
}








