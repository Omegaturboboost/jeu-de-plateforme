#ifndef CPP_QT_TPMINIPROJET_MYSCENE_H
#define CPP_QT_TPMINIPROJET_MYSCENE_H

#include <QGraphicsScene>
#include <QGraphicsLineItem>
#include <QGraphicsTextItem>
#include <QLabel>
#include <QTimer>
#include <QTime>
#include <QDebug>
#include <QKeyEvent>
#include <QPainter>
#include <QGraphicsView>
#include <QRect>
#include <QBrush>



class MyScene : public QGraphicsScene {
    Q_OBJECT

public:
    MyScene(QObject* parent = nullptr);
    void drawBackground(QPainter* painter, const QRectF& rect);
    virtual ~MyScene();

protected:
    void keyPressEvent(QKeyEvent* event);
    void keyReleaseEvent(QKeyEvent *event);


private:

    QGraphicsView* maVue;
    QTimer* timer;
    QPixmap background;
    QVector<QGraphicsPixmapItem*> Item;
    QGraphicsPixmapItem* speed;
    QPixmap pique;
    QPixmap petitPique;
    QTransform retourne;
    QTransform retourne2;
    QTransform retourne3;
    QPixmap piqueAlenvers;
    QPixmap piqueSurlaGauche;
    QPixmap piqueSurlaDroite;
    QGraphicsPixmapItem* image;
    QGraphicsPixmapItem* image2;
    QGraphicsPixmapItem* image3;
    QGraphicsPixmapItem* image4;
    QGraphicsPixmapItem* image5;
    QGraphicsPixmapItem* image6;
    QGraphicsPixmapItem* image7;
    QGraphicsPixmapItem* image8;
    QGraphicsPixmapItem* image9;
    QGraphicsPixmapItem* image10;
    QGraphicsRectItem* RectTimer;
    QGraphicsRectItem* FakePique;
    QGraphicsRectItem* RectTimer2;
    QGraphicsRectItem* FakePique2;
    QGraphicsRectItem* RectTimer3;

    QGraphicsRectItem* RectPique1;
    QGraphicsRectItem* RectPique2;
    QGraphicsRectItem* RectPique3;
    QGraphicsRectItem* RectPique4;
    QGraphicsRectItem* RectPique5;
    QGraphicsRectItem* RectPique6;
    QGraphicsRectItem* RectPique7;
    QGraphicsRectItem* RectPique8;
    QGraphicsRectItem* RectPique9;
    QGraphicsRectItem* RectPique10;
    QGraphicsRectItem* RectPique11;
    QGraphicsRectItem* RectPique12;
    QGraphicsRectItem* RectPique13;
    QGraphicsRectItem* RectPique14;
    QGraphicsRectItem* RectPique15;
    QGraphicsRectItem* RectPique16;
    QGraphicsRectItem* RectPique17;
    QGraphicsRectItem* RectPique18;
    QGraphicsRectItem* RectPique19;
//    QGraphicsPixmapItem* image_bord_map;
//    QGraphicsPixmapItem* image_plafond;
    QGraphicsTextItem* Press_R;
    QGraphicsPixmapItem* baril;
    QGraphicsPixmapItem* statueChad;
    QGraphicsPixmapItem* Fleche;
//    QGraphicsPixmapItem* spacebar;
//    QGraphicsPixmapItem* keyQ;
//    QGraphicsPixmapItem* keyD;


    QGraphicsRectItem* limite_bas;
    QGraphicsRectItem* limite_haut;
    QGraphicsRectItem* limite_gauche;
    QGraphicsRectItem* limite_droite;

    QGraphicsRectItem* pplafondmur2;
    QGraphicsRectItem* pplafondplat1;
    QGraphicsRectItem* pplafondplat2;
    QGraphicsRectItem* pplafondplat3;
    QGraphicsRectItem* plafondplat14;
    QGraphicsRectItem* plafondplat16;

    QGraphicsRectItem* mur1;
    QGraphicsRectItem* mur2;
    QGraphicsRectItem* mur3;
    QGraphicsRectItem* mur4;
    QGraphicsRectItem* mur5;
    QGraphicsRectItem* mur6;
    QGraphicsRectItem* mur7;
    QGraphicsRectItem* mur8;
    QGraphicsRectItem* pmur2;
    QGraphicsRectItem* mur3gauche;
    QGraphicsRectItem* mur3droite;
    QGraphicsRectItem* mur4gauche;
    QGraphicsRectItem* mur4droite;
    QGraphicsRectItem* mur5gauche;
    QGraphicsRectItem* mur6gauche;
    QGraphicsRectItem* mur6droite;
    QGraphicsRectItem* mur7droite;
    QGraphicsRectItem* mur8droite;

    QGraphicsRectItem* plafond1;
    QGraphicsRectItem* plafond1murgauche;
    QGraphicsRectItem* plafond1murdroite;

    QGraphicsRectItem* plafond2;

    QGraphicsRectItem* plafond3;
    QGraphicsRectItem* plafond3murgauche;
    QGraphicsRectItem* plafond3murdroite;


    QGraphicsRectItem* sol0;
    QGraphicsRectItem* sol1;
    QGraphicsRectItem* sol2;
    QGraphicsRectItem* sol0mur;
    QGraphicsRectItem* sol1mur1;
    QGraphicsRectItem* sol1mur2;
    QGraphicsRectItem* sol2mur1;
    QGraphicsRectItem* sol2mur2;

    QGraphicsRectItem* plateforme1;
    QGraphicsRectItem* plateforme2;
    QGraphicsRectItem* plateforme3;
    QGraphicsRectItem* plateforme4;
    QGraphicsRectItem* plateforme5;
    QGraphicsRectItem* plateforme6;
    QGraphicsRectItem* plateforme7;
    QGraphicsRectItem* plateforme8;
    QGraphicsRectItem* plateforme9;
    QGraphicsRectItem* plateforme10;
    QGraphicsRectItem* plateforme11;
    QGraphicsRectItem* plateforme12;
    QGraphicsRectItem* plateforme13;
    QGraphicsRectItem* plateforme14;
    QGraphicsRectItem* plateforme15;
    QGraphicsRectItem* plateforme16;
    QGraphicsRectItem* plateforme17;
    QGraphicsRectItem* plateforme18;
    QGraphicsRectItem* plateforme19;
    QGraphicsRectItem* plateforme20;


    QGraphicsRectItem* RectWin;

    //collsions coté des plateformes
//    QGraphicsRectItem* p1m1;
    QGraphicsRectItem* p1m2;
    QGraphicsRectItem* p2m1;
    QGraphicsRectItem* p2m2;
    QGraphicsRectItem* p3m1;
    QGraphicsRectItem* p3m2;
    QGraphicsRectItem* p4m2;
    QGraphicsRectItem* p5m1;
    QGraphicsRectItem* p5m2;
    QGraphicsRectItem* p6m1;
    QGraphicsRectItem* p6m2;
    QGraphicsRectItem* p7m1;
    QGraphicsRectItem* p7m2;
    QGraphicsRectItem* p8m1;
    QGraphicsRectItem* p8m2;
    QGraphicsRectItem* p9m1;
    QGraphicsRectItem* p9m2;
    QGraphicsRectItem* p10m1;
    QGraphicsRectItem* p10m2;
    QGraphicsRectItem* p11m1;
    QGraphicsRectItem* p11m2;
    QGraphicsRectItem* p12m1;
    QGraphicsRectItem* p12m2;
    QGraphicsRectItem* p13m1;
    QGraphicsRectItem* p13m2;
    QGraphicsRectItem* p14m1;
    QGraphicsRectItem* p14m2;
    QGraphicsRectItem* p15m1;
    QGraphicsRectItem* p15m2;
    QGraphicsRectItem* p16m1;
    QGraphicsRectItem* p16m2;
    QGraphicsRectItem* p17m1;
    QGraphicsRectItem* p17m2;
    QGraphicsRectItem* p18m1;
    QGraphicsRectItem* p18m2;
    QGraphicsRectItem* p19m1;
    QGraphicsRectItem* p19m2;

    QGraphicsRectItem* pauseScreen;
    QGraphicsTextItem* pauseText;

    QGraphicsRectItem* DeathScreen;
    QGraphicsTextItem* DeathText;
    QGraphicsTextItem* DeathText2;

    QGraphicsRectItem* WinScreen;
    QGraphicsTextItem* WinText;
    QGraphicsTextItem* WinText2;
//    QGraphicsTextItem* WinText3;
    QGraphicsPixmapItem* speed_content;
    QGraphicsPixmapItem* speed_mental;
    QGraphicsPixmapItem* confettis;
    QGraphicsRectItem* Score;

    QGraphicsSimpleTextItem* chronometre;

//    QPointF pos;
//    QPointF posplat2;
//    QPointF pospetplat1;
//    QPointF pospetplat2;
//    QPointF posplafondplat2;
//    QPointF posplat9;
//    QPointF posp9m1;
//    QPointF posp9m2;
//    QPointF posplat10;
//    QPointF posp10m1;
//    QPointF posp10m2;

    int secondes;
    int minutes;
    float vx, vy;
    float gravite;
    float vitessePlat2;
    float onPlat9;
    float vitessePlat9;
    float onPlat10;
    float vitessePlat10;
    float vitessePlat18;
    float saut;
    float VitRectTimer;
    float VitRectTimer2;
    float VitRectTimer3;
    bool pauseGame;
    bool RemoveWinScreen;
    bool jump;
    bool onGround;
    bool onMap;
    bool appear;
    bool speedRespawnPlat17;
    bool speedRespawnPlat18;
    bool restart;
    bool ResetChrono;

public slots:
    void update();
    void collision();
    void respawn();
//    void jump();
};


#endif //CPP_QT_TPMINIPROJET_MYSCENE_H
