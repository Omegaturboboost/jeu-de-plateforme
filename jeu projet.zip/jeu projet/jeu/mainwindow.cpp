#include "MainWindow.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{

    this->mainScene = new MyScene;

    this->mainView = new QGraphicsView;
    this->mainView->setScene(mainScene);
    this->mainScene->setBackgroundBrush(QBrush(QColor(128, 128, 128)));


    this->setCentralWidget(mainView);
    this->setWindowTitle("My main window");
    this->resize(1000, 1000);



//    QGridLayout *gridLayout = new QGridLayout(mainView);
//        gridLayout->setContentsMargins(0, 0, 0, 0);

//        QLabel *backgroundLabel = new QLabel(mainView);
//        backgroundLabel->setPixmap(QPixmap("C:/Users/Vic/Documents/cours/QT/jeu projet/build-jeu-Desktop_Qt_6_4_2_MinGW_64_bit-Debug/gazon.jpg"));
//        backgroundLabel->setScaledContents(true);
//        gridLayout->addWidget(backgroundLabel, 0, 0);

    Menu = menuBar()->addMenu(tr("&Menu"));
    QAction* actionHelp = new QAction(tr("&About"), this);
    connect(actionHelp, SIGNAL(triggered()), this, SLOT(slot_aboutMenu()));
    Menu->addAction(actionHelp);

//    QMenu* fileMenu;
//    fileMenu = menuBar()->addMenu(tr("&Fichier"));
    QAction* closeAct = new QAction(tr("&Quitter"), this);
    Menu->addAction(closeAct);

    connect(closeAct, SIGNAL(triggered()), qApp, SLOT(quit()));

    QGraphicsView* view = new QGraphicsView;
    view->setScene(mainScene);
    view->showFullScreen();
    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff); // pour enlever la barre de scroll en bas
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff); // pour enlever la barre de scroll sur le coté

}

MainWindow::~MainWindow(){

}

void MainWindow::slot_aboutMenu(){
    QMessageBox msgBox;
    msgBox.setText("A small QT/C++ projet...");
    msgBox.setModal(true); // on souhaite que la fenetre soit modale i.e qu'on ne puisse plus cliquer ailleurs
    msgBox.exec();
}


