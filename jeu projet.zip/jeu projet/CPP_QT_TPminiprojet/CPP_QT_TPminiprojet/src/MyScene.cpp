#include "MyScene.h"

MyScene::MyScene(QObject* parent) : QGraphicsScene(parent) {
 
}

MyScene::~MyScene() {

}
